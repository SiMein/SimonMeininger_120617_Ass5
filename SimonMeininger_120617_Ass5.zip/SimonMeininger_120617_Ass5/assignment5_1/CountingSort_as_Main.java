package de.assignment5_1;

public class CountingSort_as_Main {
	
	public static int [] countingSort (int [] einaus) {
	 
	int gipfel = einaus[0];
	for (int j = 0; j < einaus.length; j++) {
		if (einaus[j] > gipfel) 
		gipfel = einaus[j];
	}
	
	int [] count = new int [gipfel+1]; // Das count array ist ein Hilfsarray zur ZW-Speicherung
										//  der Zahlen aus Eingabearray !!
	
	for (int k = 0; k < einaus.length; k++) {
		int Wert = count[einaus[k]];    /* Aufruf von Inhalt aus (1.)Eingabearray(feld),
		 							 * Inhalt = Index Countarray--darin nun +1 
							* HilfsVar Wert bekommt den Inhalt d aktuellen Indexstelle ausm  Countarray zugewiesen 
		 					* Zu Beginn autom 0, nun +1  
		 					* nun bekommt Die Stelle m array den neuen Wert zugew. */  
		Wert++;
		count[einaus[k]] = Wert; 								   
	}
	
	int einbauen = 0;
	
	for (int m = 0; m < gipfel; m++) {  // Schleife nach Gr��e des (Hilfs)countarrays
		for (int z = count[m]; z > 0; z--) {  // Schleife solange bis Anzahl des aktuellen
											// Wertes auf 0 runter --somit alle Werte 
											// wieder eingebaut in Einausarray
											// wenn keine Werte doppelt dann sicher auch mit if Bed. mgl.
			
			einaus[einbauen] = m;
			einbauen++;
			
		}
	}
	
	return einaus;
	}
			
	public static void main(String[] args) {
		
		int [] inception = {5,5,8,4,9,1};
		for (int i = 0; i < inception.length; i++) {
		System.out.print(inception[i] +",");
		}
		System.out.println(" ");
		countingSort(inception);
		for (int i = 0; i < inception.length; i++) {
			System.out.print(inception[i] +",");
		}
		System.out.println("\n Hello Francesco,  this is my Prototyp of Countingsort-Implementation, -it works\n "
				+ "you can also find a modified version of this in class Sorting for ArrayList instead of\n "
				+ "normal array.  But i did not really know WHY we need a sorting algo in this assignment \n"
				+ "its about intersections i guess ...."
				+ "but unfortunatly now its to late ...    best regards  ");
	}

}