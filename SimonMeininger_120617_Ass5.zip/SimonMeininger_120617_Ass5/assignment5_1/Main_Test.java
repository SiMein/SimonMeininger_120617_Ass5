package de.assignment5_1;
import java.util.Random;  // using this stl to generate the the randoms below 
import java.util.ArrayList; // using this stl for flexible datastructur in the random version

public class Main_Test {

	public static void main(String[] args){ 
		
		Point p1 = new Point(1, 1);  // here the points are by hand - for proof that the implementation works
		Point q1 = new Point(10, 1); // scroll to the end to see the random-version 
		Point p2 = new Point(1, 2); 
		Point q2 = new Point(10, 2); 
	
		Point p3 = new Point(10, 1);
		Point q3 = new Point(0, 10); 
		Point p4 = new Point(0, 0);
		Point q4 = new Point(10, 10); 
	
		Point p5 = new Point(-5, -5);
		Point q5 = new Point(0, 0); 
		Point p6 = new Point(1, 1);
		Point q6 = new Point(10, 10); 
	
		System.out.println("\nFirst Testcase - gis1 :");
		GenIntSec gis1 = new GenIntSec(p1, q1, p2, q2);
		gis1.check_if_intersect(); // results by printoutstream
	
		System.out.println("\nSecond Testcase - gis2 :");
		GenIntSec gis2 = new GenIntSec(p3, q3, p4, q4);
		gis2.check_if_intersect();
	
		System.out.println("\nThird Testcase - gis3 :");
		GenIntSec gis3 = new GenIntSec(p5, q5, p6, q6);
		gis3.check_if_intersect(); 
	
	
	
		System.out.println("\n now here is the Random-Version ---------------------------------------------\n");
	
		Random numbox = new Random();
		int[] numbArray1 = new int[8];
		ArrayList<GenIntSec> randPointList = new ArrayList<GenIntSec>();
		
		for (int i=0; i<10; i++){		
			for (int j=0; j<8; j++) {  	//create 8 randomnumbers for 4 points for 2 lines for 1 GenIntSec-Object
				numbArray1[j] = numbox.nextInt(100); // for clarity only values between 
			}											
			Point po1 = new Point(numbArray1[0], numbArray1[1]);
			Point po2 = new Point(numbArray1[2], numbArray1[3]);
			Point po3 = new Point(numbArray1[4], numbArray1[5]);
			Point po4 = new Point(numbArray1[6], numbArray1[7]);
			GenIntSec gitRand = new GenIntSec(po1, po2, po3, po4);
			randPointList.add(gitRand);
			System.out.println(i+1 + ". Testcase - in random version (by loop) :");
			//System.out.print(randPointList.get(p1.x));
			gitRand.check_if_intersect(); 
			}
		System.out.println("\n randPointList.size() ist : " + randPointList.size());
			
		GenIntSec loophelper = new GenIntSec(p5, q5, p6, p6);
		
		
		for (int k = 0; k < randPointList.size(); k++) {
			System.out.println(randPointList.get(k).p1.x); // Access/Sorting by one point of x-axist
			int i = (randPointList.get(k).p1.x) + 1;
		}
		
		
		Sorting sorting1 = new Sorting(randPointList);
		sorting1.countingSort();
		
		
		
		
	}
}
