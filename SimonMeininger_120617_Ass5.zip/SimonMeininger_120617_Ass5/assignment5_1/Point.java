package de.assignment5_1;


public class Point {  
	
	public int x;
	public int y;

	Point(int x, int y) { 
	   this.x = x; 
	   this.y = y; 
	} 
}