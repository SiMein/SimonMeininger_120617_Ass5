package de.assignment5_1;

import java.util.ArrayList;

public class Sorting {
	
	public ArrayList<GenIntSec> inout;
	
	Sorting(ArrayList<GenIntSec> inout){  // constr gets an ArrayList
		this.inout = inout;
	}
	
	public ArrayList<GenIntSec> countingSort() {  //sorting-method using his ArrayList-member
										
		int max = Integer.MIN_VALUE;  // searching the max for sizing of the helperarray		

	    for (int i = 0; i < inout.size(); i++){
	        if (inout.get(i).p1.x > max){
	            max = inout.get(i).p1.x;
	        }
	    }
	    int[] helperarray = new int[max+1]; // +1 because the 0 needs also a field in the array
	    System.out.println("Hello from countingSort()method from Sorting class");
	    System.out.println("max is : " + max);
	    System.out.println("helpersarraysize is : " + (max) + ",   " + helperarray.length);

	    
		for (int k = 0; k < inout.size(); k++) {
			int wert = helperarray[inout.get(k).p1.x];   
							
			wert++;
			helperarray[k] = wert;
			helperarray[inout.get(k).p1.x] = wert; 								   
		}
	
		int f = 0;
	
		for (int m = 0; m < inout.size(); m++) {  
			for (int z = helperarray[m]; z > 0; z--) { 
																																			
				inout.get(f).p1.x = m;
				f++;			
			}
		} 
		return inout;
	}
}
