package de.assignment5_1;

public class GenIntSec {  // Method-class for checking Intersection
	Point p1;
	Point q1;
	Point p2;
	Point q2;
	
	GenIntSec(Point p1,Point q1,Point p2,Point q2){	// (only) custom -constr.
		this.p1 = p1;			// for better clarity -no getters/setters 
		this.q1 = q1;
		this.p2 = p2;
		this.q2 = q2;
	}
	
	public void check_if_intersect() { // give the result as printout / its called from Main_Test
		
							// 2lines - 4 points - 4 cases 
		 int x1 = clock_check(p1, q1, p2);  
		 int x2 = clock_check(p1, q1, q2); 
		 int x3 = clock_check(p2, q2, p1); 
		 int x4 = clock_check(p2, q2, q1); 
		 					
		 
		 if (x1 != x2 && x3 != x4 || // Normal case - because the results are not equal, so there is a intersection
			// Special cases when clock_check is 0 but its collinear (part-)overlap. Again 4 points for 4 cases -
			 x1 == 0 && point_hit_line(p1, p2, q1) || // the middle one is the point to test if its between the outers
			 x2 == 0 && point_hit_line(p1, q2, q1) ||  
			 x3 == 0 && point_hit_line(p2, p1, q2) ||  
			 x4 == 0 && point_hit_line(p2, q1, q2)) { 
		     System.out.println("Yes ! there is a intersection ! ");
		 } else {
			 System.out.println("No Intersection ! "); 
		 }
	}
	
	public boolean point_hit_line(Point p, Point q, Point r){  // Specialcase
	// checks if q is on line pr.this can only be true when its not beyond FOR ALL max and min of the x and y axis
		if (q.x <= Math.max(p.x, r.x) && q.x >= Math.min(p.x, r.x) &&  // 
				q.y <= Math.max(p.y, r.y) && q.y >= Math.min(p.y, r.y)) { 
			return true; 
		} else {
			return false; 
		}
	} 

	public int clock_check(Point p, Point q, Point r) {  // Normalcase
						// using geometrical Formal to find the result
		int result = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y); 
		if (result == 0) {
			return 0; // collinear 
		} else {
			return (result > 0)? 1: -1; // clock (+1) or counterclock (-1) 
		}
	} 
}
